<?php
require_once "includes/db.php";
$stmt = $pdo->query("SELECT * FROM portraits");
$portraits = $stmt->fetchAll();
?>
<!DOCTYPE html><html><head><title>Galerie</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body><h1>Portraits</h1><div class="gallery">
<?php foreach ($portraits as $p): ?><div class="portrait-card">
<img src="assets/images/<?= htmlspecialchars($p['image']) ?>" width="200">
<p><?= htmlspecialchars($p['name']) ?></p></div>
<?php endforeach; ?></div></body></html>
