<?php
session_start();if(!isset($_SESSION['admin_id'])){header("Location: login.php");exit;}
require_once "../includes/db.php";
$ps=$pdo->query("SELECT * FROM portraits");$portraits=$ps->fetchAll();
?><!DOCTYPE html><html><body><h1>Portraits</h1><a href="add.php">Ajouter</a><table border="1">
<tr><th>ID</th><th>Nom</th><th>Image</th></tr>
<?php foreach($portraits as $p): ?><tr><td><?=$p['id']?></td><td><?=$p['name']?></td>
<td><img src="../assets/images/<?=$p['image']?>" width="80"></td></tr><?php endforeach; ?>
</table></body></html>
