<?php
session_start();require_once "../includes/db.php";
if($_POST){$u=$_POST['username'];$p=$_POST['password'];
$s=$pdo->prepare("SELECT * FROM admins WHERE username=?");$s->execute([$u]);$a=$s->fetch();
if($a && password_verify($p,$a['password'])){$_SESSION['admin_id']=$a['id'];header("Location: dashboard.php");exit;}
$error="Identifiants incorrects";}
?>
<!DOCTYPE html><html><body><h1>Login</h1><?php if(isset($error)) echo $error; ?>
<form method="post"><input name="username"><input name="password" type="password"><button>OK</button></form>
</body></html>
