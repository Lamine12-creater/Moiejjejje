<?php
session_start();if(!isset($_SESSION['admin_id'])){header("Location: login.php");exit;}
require_once "../includes/db.php";
if($_POST){$n=$_POST['name'];$img=$_FILES['image'];
$dir="../assets/images/";$f=$dir.basename($img["name"]);move_uploaded_file($img["tmp_name"],$f);
$s=$pdo->prepare("INSERT INTO portraits(name,image) VALUES(?,?)");$s->execute([$n,basename($img["name"])]);header("Location: portraits.php");exit;}
?><!DOCTYPE html><html><body><h1>Ajouter</h1>
<form method="post" enctype="multipart/form-data"><input name="name"><input name="image" type="file"><button>OK</button></form>
</body></html>
