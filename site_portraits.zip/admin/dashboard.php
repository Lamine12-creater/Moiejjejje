<?php
session_start();if(!isset($_SESSION['admin_id'])){header("Location: login.php");exit;}
?><!DOCTYPE html><html><body><h1>Dashboard</h1><a href="portraits.php">Gérer portraits</a></body></html>